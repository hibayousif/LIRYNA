function updateBase(type, element) {
  const baseLayer = document.getElementById('layer-base');
  const cupLabel  = document.getElementById('cup-label');

  if (type === 'matcha') {
    baseLayer.style.background = '#91AC41';
    cupLabel.textContent = 'Matcha Latte';
  } else if (type === 'espresso') {
    baseLayer.style.background = '#6F4E37';
    cupLabel.textContent = 'Espresso';
  } else if (type === 'juice') {
    baseLayer.style.background = '#FFB347';
    cupLabel.textContent = 'Healthy Juice';
  }

  const buttons = element.parentElement.querySelectorAll('.opt-btn');
  buttons.forEach(btn => btn.classList.remove('active'));
  element.classList.add('active');
}

function toggleActive(element) {
  const parent = element.parentElement;
  parent.querySelectorAll('.opt-btn').forEach(btn => btn.classList.remove('active'));
  element.classList.add('active');
}

function changeBakery(type, element) {
  const preview = document.getElementById('bakery-preview');
  const label   = document.getElementById('bakery-label');

  const emojis = {
    plain:     { icon: '🥐', name: 'Plain Croissant'     },
    cheese:    { icon: '🧀🥐', name: 'Cheese Croissant'  },
    chocolate: { icon: '🍫🥐', name: 'Chocolate Croissant' },
    sandwich:  { icon: '🥪',  name: 'Sandwich'            }
  };

  preview.textContent  = emojis[type].icon;
  label.textContent    = emojis[type].name;

  const parent = element.parentElement;
  parent.querySelectorAll('.opt-btn').forEach(btn => btn.classList.remove('active'));
  element.classList.add('active');
}

function changeBeauty(type, element) {
  const previewBox = document.getElementById('beauty-preview');
  const icon       = document.getElementById('beauty-icon');
  const name       = document.getElementById('beauty-name');

  const items = {
    balm:  { icon: '💄', name: 'Lip Balm'   },
    cream: { icon: '💅🏻', name: 'Hand Cream'  },
    gloss: { icon: '👄', name: 'Lip Gloss'   }
  };

  icon.textContent = items[type].icon;
  name.textContent = items[type].name;
  previewBox.classList.remove('hidden');

  const parent = element.parentElement;
  parent.querySelectorAll('.opt-btn').forEach(btn => btn.classList.remove('active'));
  element.classList.add('active');
}

function placeOrder() {
  document.querySelector('.site-header').style.display    = 'none';
  document.querySelector('.how-it-works').style.display   = 'none';
  document.getElementById('builder-interface').style.display = 'none';

  document.getElementById('success-screen').classList.remove('hidden');
  window.scrollTo(0, 0);
}